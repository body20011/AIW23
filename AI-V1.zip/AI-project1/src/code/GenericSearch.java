package code;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Collections;

public class GenericSearch {

	String [] actions = { "BUILD1", "BUILD2", "RequestFood", "RequestMaterials", "RequestEnergy", "WAIT"};
	Object [] last = new Object[2]; 
	List<Node> nodes = new ArrayList<Node>();
	HashSet<String>  duplicateStates =new HashSet<>();  
	int expansions = 0;
	boolean isDelayFood = false;
	boolean isDelayMaterial = false;
	boolean isDelayEnergy = false;
	int amount = 0;
	boolean isDuplicate =false;

	
	public Object [] General_Search(int[] initState, String algo, boolean visual, LLAPSearch x){
		if(initState[0] >= 100) {
			last[0] = ";0";
			last[1] = "1";
			return last;
		}
		Node root = new Node(initState,null,null,0,0,0);
		
		nodes.add(root);
		while (!nodes.isEmpty()){
			
			Node temp = nodes.remove(0);
			System.out.println(nodes.size());
			expansions++;
			//System.out.println(temp.action+ " ");
			if (temp.state[0]>=100) {
				last[0] = temp;
				last[1] = "" + expansions;
				return last;
			}
			for (int i = 0;i<actions.length;i++) {
				if (temp.state[1]<=0 || temp.state[2]<=0 || temp.state[3]<=0 || temp.state[4]>=100000)
					break;
				Node temp2 = null;
				int [] newState = new int[5];
				if (isDelayFood && temp.delay <=0 && amount>0) {
					newState[1]+= amount;
					isDelayFood =false;
					amount =0;
				}else if (isDelayMaterial && temp.delay <=0 && amount>0) {
					newState[2]+= amount;
					isDelayMaterial =false;
					amount =0;
				}else if (isDelayEnergy && temp.delay <=0 && amount>0) {
					newState[3]+= amount;
					isDelayFood =false;
					amount =0;
				}
				if(actions[i]=="BUILD1" && temp.state[1]-x.foodUseBuild1>=0 && temp.state[2]-x.materialUseBuild1>=0 && temp.state[3]-x.energyUseBuild1>=0 && temp.state[4] + x.priceBuild1 + x.resources <= x.budget) {
					newState[0] = temp.state[0] + x.prosperityBuild1;
					newState[1] = temp.state[1] - x.foodUseBuild1;
					newState[2] = temp.state[2] - x.materialUseBuild1;
					newState[3] = temp.state[3] - x.energyUseBuild1;
					newState[4] = temp.state[4] + x.priceBuild1 + x.resources;
					int delay = 0;
					if(temp.delay>0) {
						delay = temp.delay-1;
					}
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.priceBuild1 + x.resources,delay);
				}else if(actions[i]=="BUILD2" && temp.state[1]-x.foodUseBuild2>=0 && temp.state[2]-x.materialUseBuild2>=0 && temp.state[3]-x.energyUseBuild2>=0 && temp.state[4] + x.priceBuild2 +x.resources <= x.budget) {
					newState[0] = temp.state[0] + x.prosperityBuild2;
					newState[1] = temp.state[1] - x.foodUseBuild2;
					newState[2] = temp.state[2] - x.materialUseBuild2;
					newState[3] = temp.state[3] - x.energyUseBuild2;
					newState[4] = temp.state[4] + x.priceBuild2 + x.resources;
					int delay = 0;
					if(temp.delay>0) {
						delay = temp.delay-1;
					}
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.priceBuild2 + x.resources,delay);
				}else if(actions[i]=="RequestFood" && temp.delay==0 && temp.state[4] + x.resources <= x.budget) {
					newState[0] = temp.state[0];
					newState[1] = temp.state[1] - 1;
					newState[2] = temp.state[2] - 1;
					newState[3] = temp.state[3] - 1;
					newState[4] = temp.state[4] + x.resources;
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.resources,x.delayReqFood);
					
					isDelayFood =true;
					amount  = x.amountReqFood;
					
				}else if(actions[i]=="RequestMaterials" && temp.delay==0 && temp.state[4] + x.resources <= x.budget) {
					newState[0] = temp.state[0];
					newState[1] = temp.state[1] - 1;
					newState[2] = temp.state[2] - 1;
					newState[3] = temp.state[3] - 1;
					newState[4] = temp.state[4] + x.resources;
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.resources,x.delayReqMaterial);
					
					isDelayMaterial =true;
					amount = x.amountReqMaterial;
					
				}else if(actions[i]=="RequestEnergy" && temp.delay==0 && temp.state[4] + x.resources <= x.budget) {
					newState[0] = temp.state[0];
					newState[1] = temp.state[1] - 1;
					newState[2] = temp.state[2] - 1;
					newState[3] = temp.state[3] - 1;
					newState[4] = temp.state[4] + x.resources;
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.resources,x.delayReqEnergy);
					
					isDelayEnergy =true;
					amount = x.amountReqEnergy;
						
				}else if(actions[i]=="WAIT" && temp.delay>0 && temp.state[4] + x.resources <= x.budget) {
					newState[0] = temp.state[0];
					newState[1] = temp.state[1] - 1;
					newState[2] = temp.state[2] - 1;
					newState[3] = temp.state[3] - 1;
					newState[4] = temp.state[4] + x.resources;
					int delay = 0;
					if(temp.delay>0) {
						delay = temp.delay-1;
					}
					temp2 = new Node(newState, temp, actions[i],temp.depth+1,x.resources,delay);
				}
				if(temp2 != null) {
					String duplicate = temp2.state.toString() + temp2.action;
					int size = duplicateStates.size();
					duplicateStates.add(duplicate);
					if(duplicateStates.size()==size) {
						isDuplicate=true;
					}else {
						isDuplicate = false;
					}
					
				}
				switch(algo) {
				case "BF":
					if (temp2 != null && !isDuplicate) {
						nodes.add(temp2);
										}
					break;
				case "DF":
					if (temp2 != null && !isDuplicate) {
						nodes.add(0, temp2);
										}
					break;
				case "UC":
					if (temp2 != null && !isDuplicate) {
					nodes.add(temp2);
					Collections.sort(nodes);
					}
					break;
				}
				
			}
				
			
		}
			 
		last[0] = false;
		return last;
	}
	
	
}
