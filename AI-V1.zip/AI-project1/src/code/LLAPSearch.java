package code;

public class LLAPSearch extends GenericSearch {
	int unitPriceFood;
	int unitPriceMaterial;
	int unitPriceEnergy;
	int amountReqFood;
	int delayReqFood;
	int amountReqMaterial;
	int delayReqMaterial;
	int amountReqEnergy;
	int delayReqEnergy;
	int priceBuild1;
	int foodUseBuild1;
	int materialUseBuild1;
	int energyUseBuild1;
	int prosperityBuild1;
	int priceBuild2;
	int foodUseBuild2;
	int materialUseBuild2;
	int energyUseBuild2;
	int prosperityBuild2;
	int budget = 100000;
	int resources;
	

	
	public  int[] parser(String s) {
		String [] parts = s.split(";");
		String tmp0 = parts[0] + "," + parts[1] + ",0";
		
		String [] tmp = tmp0.split(",");
		
		int [] state = new int[5];
		for(int i =0;i < 5 ; i++) {
			state[i] = Integer.parseInt(tmp[i]);
		}
		String tmpValues = "";
		for (int i = 2; i < parts.length; i++) {
			tmpValues += parts[i] + ",";
		}
		
		
		String [] tmp2 = tmpValues.split(",");
		this.unitPriceFood = Integer.parseInt(tmp2[0]);
		this.unitPriceMaterial = Integer.parseInt(tmp2[1]);
		this.unitPriceEnergy = Integer.parseInt(tmp2[2]);
		this.amountReqFood = Integer.parseInt(tmp2[3]);
		this.delayReqFood = Integer.parseInt(tmp2[4]);
		this.amountReqMaterial = Integer.parseInt(tmp2[5]);
		this.delayReqMaterial = Integer.parseInt(tmp2[6]);
		this.amountReqEnergy = Integer.parseInt(tmp2[7]);
		this.delayReqEnergy = Integer.parseInt(tmp2[8]);
		this.priceBuild1 = Integer.parseInt(tmp2[9]);
		this.foodUseBuild1 = Integer.parseInt(tmp2[10]);
		this.materialUseBuild1 = Integer.parseInt(tmp2[11]);
		this.energyUseBuild1 = Integer.parseInt(tmp2[12]);
		this.prosperityBuild1 = Integer.parseInt(tmp2[13]);
		this.priceBuild2 = Integer.parseInt(tmp2[14]);
		this.foodUseBuild2 = Integer.parseInt(tmp2[15]);
		this.materialUseBuild2 = Integer.parseInt(tmp2[16]);
		this.energyUseBuild2 = Integer.parseInt(tmp2[17]);
		this.prosperityBuild2 = Integer.parseInt(tmp2[18]);
		this.resources = Integer.parseInt(tmp2[0]) + Integer.parseInt(tmp2[1]) + Integer.parseInt(tmp2[2]);
		return state;
	}
	
	public static String solve(String initState, String algo, boolean visual) {
		
		LLAPSearch x = new LLAPSearch();
		int[] state = x.parser(initState);
		Object [] o = x.General_Search(state, algo, visual,x);
		String action = "";
		if(o[0] instanceof Node){
			Node n = (Node)o[0];
			Node temp = new Node(null,null,null,0,0,0);
			temp = n;
			while (temp.parentNode != null) {
			    action =temp.action+ "," + action;
				temp = temp.parentNode;
				
			}
			return action + ";" + n.state[4]+ ";" + o[1];
		}else if (o[0] instanceof Boolean) {
			return "NOSOLUTION";
		}else if (o[0] instanceof String) {
			return (String)o[0]+o[1];
		}
		
		return null;
	}
	
	
	public static void main(String[] args) {
		
		LLAPSearch s = new LLAPSearch();
		System.out.print(s.solve("17;" +
                "49,30,46;" +
                "7,57,6;" +
                "7,1;20,2;29,2;" +
                "350,10,9,8,28;" +
                "408,8,12,13,34;", "DF", false));
        
	}
}
