package code;

public class Node implements Comparable<Node> {
	int[] state;
	Node parentNode;
	String action;
	int depth;
	int pathCost;
	int delay;
	
	public Node(int[] state, Node parentNode, String action, int depth, int pathCost, int delay) {
		this.state =state;
		this.parentNode = parentNode;
		this.action = action;
		this.depth = depth;
		this.pathCost = pathCost;
		this.delay =delay;
	}
	
	@Override
    public int compareTo(Node other) {
        return Integer.compare(this.state[4], other.state[4]);
    }
}
